#include <stdio.h>
#include <glib/gstdio.h>

/*
pkg-config --modversion glib-2.0 : 2.40.0
*/

// Compiled with: gcc test.c -Wall `pkg-config --cflags glib-2.0`-o test `pkg-config --libs glib-2.0`
// Use image file from https://github.com/GNOME/gtk/blob/gtk-2-24-win32/demos/gtk-demo/gnome-fs-directory.png
int main()
{
  // fopen - Work as expected (no translation for "rb")
  FILE* f = fopen("gnome-fs-directory.png", "rb");
  guchar buffer[10];
  int size = fread(&buffer, 1, 10, f);

  printf("f.size = %i\n", size);
  int i; for (i = 0; i < size; i++) printf("f.byte = %i\n", buffer[i]);

  // g_fopen - Unexpectedly apply translation
  FILE* g = g_fopen("gnome-fs-directory.png", "rb");
  size = fread(&buffer, 1, 10, g);

  printf("g.size = %i\n", size);
  for (i = 0; i < size; i++) printf("g.byte = %i\n", buffer[i]);

  return 0;
}
