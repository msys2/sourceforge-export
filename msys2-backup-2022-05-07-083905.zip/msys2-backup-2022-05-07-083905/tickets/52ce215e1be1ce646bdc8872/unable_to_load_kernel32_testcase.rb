require 'fiddle'

## Work
kernel = Fiddle::Handle.new("c:/Windows/System32/kernel32.dll")
puts "Function address: #{kernel['GetEnvironmentStrings']}"

# Does not work
begin
  kernel = Fiddle::Handle.new("kernel32.dll")
  puts "Function address: #{kernel['GetEnvironmentStrings']}"
rescue Fiddle::DLError
  puts "Can't load kernel32.dll"
end
		  
### 
## The test case above is the simplest way to reproduce the
## problem. However, the problem will pop up elsewhere like
## with the code below taken from `rubygems` where they use
## 'kernel32.dll' directly.
##
## Rubygems 2.2.0,
##  File rubygems/remote_fetcher.rb
##  Method api_endpoint
##  Line #87

=begin
	require 'resolv'

	dns = Resolv::DNS.new()

	host = "rubygems.org"

	begin
	  res = dns.getresource("_rubygems._tcp.#{host}", Resolv::DNS::Resource::IN::SRV)
	rescue Resolv::ResolvError
	  puts "A Resolv error occurred."
	end
=end