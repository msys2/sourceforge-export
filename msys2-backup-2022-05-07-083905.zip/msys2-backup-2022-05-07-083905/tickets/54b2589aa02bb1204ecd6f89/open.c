/* Simple open command line utility.
 * Copyright 2014 Martin Mitas
 * Placed in public domain.
 */

#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <shellapi.h>


int
_tmain(int argc, TCHAR** argv)
{
    SHELLEXECUTEINFO sei;
    int i;

    sei.cbSize = sizeof(sei);
    sei.fMask = SEE_MASK_FLAG_DDEWAIT;
    sei.nShow = SW_SHOWNORMAL;
    sei.lpVerb = _T("open");

    for(i = 1; i < argc; i++) {
        int j, n;
        /* Translate '/' to '\\' */
        n = wcslen(argv[i]);
        for(j = 0; j < n; j++) {
            if(argv[i][j] == _T('/'))
                argv[i][j] = _T('\\');
        }

        sei.lpFile = argv[i];
        ShellExecuteEx(&sei);
    }

    return 0;
}
